/*
    3-17-08
    Nathan Seidle
    nathan@sparkfun.com
    Copyright Spark Fun Electronics� 2008
    
    Written for a PIC 16F88 running SparkFun bootloader at internal 8MHz.
    Compiled with CC5x compiler.

    Basic software I2C interactions with the ADJD-S371-Q999 color
    sensor. Sensor works great but requires calibration. This firwmare
    is only meant to demonstrate simple command interface.
    
    The software I2C routines are heavily tested and seem to work well
    with many I2C devices.
*/
#define Clock_8MHz
#define Baud_9600

#include "c:\Global\Code\C\16F88.h"  // device dependent interrupt definitions

#pragma origin 4

#include "c:\Global\Code\Pics\Code\Delay.c"   //Standard delays
#include "c:\Global\Code\Pics\Code\stdio.c"   //Software based Basic Serial IO

#define STATUS_LED PORTB.3

void boot_up(void);

#define WRITE_sda() TRISB = TRISB & 0b.1011.1111 //SDA must be output when writing
#define READ_sda()  TRISB = TRISB | 0b.0100.0000 //SDA must be input when reading - don't forget the resistor on SDA!!

#define SCL PORTB.7
#define SDA PORTB.6

#define I2C_DELAY   1

#define ACK     1
#define NO_ACK  0

#define DEVICE_WRITE    0xE8 //Default ADJD-S371 I2C address - write
#define DEVICE_READ     0xE9 //Default ADJD-S371 I2C address - read

#define CAP_RED         0x06
#define CAP_GREEN       0x07
#define CAP_BLUE        0x08
#define CAP_CLEAR       0x09

#define INT_RED_LO      0x0A
#define INT_RED_HI      0x0B
#define INT_GREEN_LO    0x0C
#define INT_GREEN_HI    0x0D
#define INT_BLUE_LO     0x0E
#define INT_BLUE_HI     0x0F
#define INT_CLEAR_LO    0x10
#define INT_CLEAR_HI    0x11

#define DATA_RED_LO     0x40
#define DATA_RED_HI     0x41
#define DATA_GREEN_LO   0x42
#define DATA_GREEN_HI   0x43
#define DATA_BLUE_LO    0x44
#define DATA_BLUE_HI    0x45
#define DATA_CLEAR_LO   0x46
#define DATA_CLEAR_HI   0x47

void adjd_s371_read(void);
void adjd_init(void);

void i2c_ack_polling(uns8 device_address);
void i2c_start(void);
void i2c_stop(void);
uns8 i2c_read_byte(void);
bit i2c_send_byte(uns8 out_byte);
uns8 read_register(uns8 register_name);
void write_register(uns8 register_name, uns8 register_value);

void main(void)
{
    uns8 choice;
    
    boot_up();
        
    printf("\n\r\n\ADJD Testing\n\r", 0);

    adjd_init();
    
    while(1)
    {
        adjd_s371_read();
        //delay_ms(10);
    }
    
    while(1);

}//End Main

void boot_up(void)
{
    //OSCCON = 0b.0111.0000; //Setup internal oscillator for 8MHz
    //while(OSCCON.2 == 0); //Wait for frequency to stabilize

    //Setup Ports
    ANSEL = 0b.0000.0000; //Turn off A/D

    PORTA = 0b.0000.0000;
    TRISA = 0b.0000.0000;

    PORTB = 0b.0001.0000;
    TRISB = 0b.0000.0100;   //0 = Output, 1 = Input RX on RB2

    //Setup the hardware UART module
    //=============================================================
    SPBRG = 51; //8MHz for 9600 inital communication baud rate
    //SPBRG = 59; //9.216MHz for 9600 inital communication baud rate
    //SPBRG = 4; //9.216MHz for 115200 inital communication baud rate
    //SPBRG = 129; //20MHz for 9600 inital communication baud rate

    TXSTA = 0b.0010.0100; //8-bit asych mode, high speed uart enabled
    RCSTA = 0b.1001.0000; //Serial port enable, 8-bit asych continous receive mode
    //=============================================================

}

void adjd_init(void)
{
    write_register(CAP_RED, 0x05);
    write_register(CAP_GREEN, 0x05);
    write_register(CAP_BLUE, 0x05);
    write_register(CAP_CLEAR, 0x05);
    
    write_register(INT_RED_LO, 0xC4);
    write_register(INT_RED_HI, 0x09);
    write_register(INT_GREEN_LO, 0xC4);
    write_register(INT_GREEN_HI, 0x09);
    write_register(INT_BLUE_LO, 0xC4);
    write_register(INT_BLUE_HI, 0x09);
    write_register(INT_CLEAR_LO, 0xC4);
    write_register(INT_CLEAR_HI, 0x09);
}

//Init the sensor and read out the humidity and temperature data
void adjd_s371_read(void)
{
    uns8 response;
    uns16 red, green, blue, clear;

    //Check ability to read CAP_RED (should be 15)
    //response = read_register(CAP_RED);
    //printf("CAP_RED:%d ", response);

    write_register(0x00, 0b.0000.0001); //Get sensor reading
    
    uns8 i = 0;
    while(1)
    {
        response = read_register(0x00);
        if (response == 0) break;
        i++;
    }
    printf("i=%d ", i);
        
    //Red
    red.low8 = read_register(DATA_RED_LO);
    red.high8 = read_register(DATA_RED_HI);

    //Green
    green.low8 = read_register(DATA_GREEN_LO);
    green.high8 = read_register(DATA_GREEN_HI);

    //Blue
    blue.low8 = read_register(DATA_BLUE_LO);
    blue.high8 = read_register(DATA_BLUE_HI);

    //Clear
    clear.low8 = read_register(DATA_CLEAR_LO);
    clear.high8 = read_register(DATA_CLEAR_HI);
    

    printf("R(%h) ", red);
    printf("G(%h) ", green);
    printf("B(%h) ", blue);
    printf("C(%h)", clear);
    
    printf("\r", 0);
}

//Reads a register from LIS
uns8 read_register(uns8 register_name)
{
    uns8 in_byte;
    
    i2c_ack_polling(DEVICE_WRITE);

    i2c_start();
    i2c_send_byte(DEVICE_WRITE); 
    i2c_send_byte(register_name); //Write register address   
    //i2c_stop();

    i2c_start(); //Repeat start (SR)
    i2c_send_byte(DEVICE_READ); //Now ask the IC to report on the last command
    in_byte = i2c_read_byte();
    i2c_stop();
        
    return(in_byte);
}

//Write to a register in LIS
void write_register(uns8 register_name, uns8 register_value)
{
    i2c_ack_polling(DEVICE_WRITE);

    i2c_start();
    i2c_send_byte(DEVICE_WRITE); 
    i2c_send_byte(register_name); //Write register address
    i2c_send_byte(register_value); //Write data
    i2c_stop();

    //Return nothing
}

//Software I2C Routines
//====================================
void i2c_ack_polling(uns8 device_address)
{
    while(1)
    {
        i2c_start();
        if (i2c_send_byte(device_address) == ACK) break;
    }
    i2c_stop();
}

void i2c_start(void)
{
    WRITE_sda();
    SDA = 1;
    delay_us(I2C_DELAY);

    SCL = 1;
    delay_us(I2C_DELAY);

    SDA = 0;
    delay_us(I2C_DELAY);
}

//The I2C Clock has a minimum of 2us high time and 2us low time
void i2c_stop(void)
{
    SCL = 0;
    delay_us(I2C_DELAY);

    WRITE_sda();

    SDA = 0;
    delay_us(I2C_DELAY);

    SCL = 1;
    delay_us(I2C_DELAY);

    SDA = 1;
    delay_us(I2C_DELAY);
}

//The I2C Clock has a minimum of 2us high time and 2us low time
//8MHz = 0.5us per instruction
uns8 i2c_read_byte(void)
{
    int j, in_byte;

    SCL = 0;

    READ_sda();

    for(j = 0 ; j < 8 ; j++)
    {
        SCL = 0;
        delay_us(I2C_DELAY);

        SCL = 1;
        delay_us(I2C_DELAY);

        in_byte = rl(in_byte);
        in_byte.0 = SDA;
    }

    //Send 9th bit acknowledge
/*
    For single byte reads, there is NMAK or no master acknowledge
    SCL = 0;
    WRITE_sda();
    SDA = 0;
    delay_us(I2C_DELAY);
    SCL = 1;

    delay_us(I2C_DELAY);
    SCL = 0;

    delay_us(I2C_DELAY);
    SDA = 1;
    while(1);
*/
    return(in_byte);
}

//The I2C Clock has a minimum of 2us high time and 2us low time
//8MHz = 500ns per instruction
bit i2c_send_byte(uns8 out_byte)
{
    uns8 i;

    WRITE_sda();

    for(i = 0 ; i < 8 ; i++)
    {
        SCL = 0;
        delay_us(I2C_DELAY);

        out_byte = rl(out_byte);
        SDA = Carry;
        delay_us(5);

        SCL = 1;
        delay_us(I2C_DELAY);
    }

    //Read ack
    SCL = 0;
    delay_us(I2C_DELAY);

    READ_sda();

    SCL = 1;
    delay_us(I2C_DELAY);

    //Wait for IC to acknowledge
    for(i = 0 ; i < 255 ; i++)
        if(SDA == 0) break;

    SCL = 0;
    delay_us(I2C_DELAY);

    if (i == 255) return(NO_ACK);
    
    return(ACK);
}
//====================================
