/* Example code for Avago RGB sensor using LPC2148 breakout board */
 

#include <stdio.h>
#include <stdlib.h>
#include "LPC214x.h"
#include "system.h"
#include "intcomm.h"
#include "iic.h"
#include "printmacros.h"
#include "avago.h"

/* Function Prototypes */
void gain_optimization(void);
void set_caps(void);
void set_ints(void);
void toggle_led(void);
void show_color(void);
void sensor_operation(void);
char getch(void);
unsigned int getint(void);

int led = 0;

int main(void)
{
  unsigned char data[2] = { 0,0 };
/* Do basic initialization */
  boot_up(); /* From system.c */

/* Initialize IIC Module */
  i2c0_init();  /* From iic.c */
  i2c0ISR_init(); /* From iic.c */
  IODIR0 |= (1 << 4);
  PRINTF0("I2C started\n\r");
  PRINTF0("Checking for Avago RGB Sensor");
  while(1)
  {
    PRINTF0(".");
    if(i2c0_master_send(0xE8,data,1) == 0) /* i2c0 routines come from iic.c */
    {
      PRINTF0("\n\rFound Avago RGB Sensor!\n\r");
      gain_optimization();
    }
    delay_ms(1000); /* But pause for ~1 second */
  }
}

void gain_optimization(void)
{
	char c;
	PRINTF0("\n\rAvago RGB Sensor Gain Optimization\n\r\n\r");
	PRINTF0("  (1) Set capacitor registers\n\r");
	PRINTF0("  (2) Set time interval register\n\r");
	PRINTF0("  (3) Toggle LED\n\r");
	PRINTF0("  (4) Run ('A' to stop)\n\r");
	PRINTF0("  (5) Optimization finished\n\r\n\r");
	PRINTF0("Choice:");
	c = getch();
	switch(c) {
		case '1':
			set_caps();
			break;
		case '2':
			set_ints();
			break;
		case '3': 
			toggle_led();
			break;
		case '4':
			show_color();
			break;
		case '5':
			sensor_operation();
			break;
	}

}	
void set_caps(void)
{
	int color_reg;
	char c;
	unsigned char data[2] = {0,0};

	PRINTF0("\n\rChoose number of capacitors (0-F): ");
	c = getch();
	if(c <= '9'){ c -= 48; }
	else{ c -= 55; }
	color_reg = CAP_REG_BASE;
	while(color_reg <= 0x09)
	{	
		data[0] = color_reg;
		data[1] = c;
		i2c0_master_send(AVAGO_SLAVE,data,2);
		color_reg++;
	}
	PRINTF1("\n\rWrote %d to all capacitor registers\n\r", data[1]);
	gain_optimization();
}

void set_ints(void)
{
	int color_reg;
	int newint;
	unsigned char data[2] = {0,0};
	color_reg = INT_REG_BASE;
	PRINTF0("\n\rNew integration time value ending in 'A' (0-4095):");
	newint = getint();
	while(color_reg <= 0x11)
	{
		data[0] = color_reg;
		data[1] = (char)newint & 0x00FF;
		i2c0_master_send(AVAGO_SLAVE,data,2);
		data[0] = data[0] + 1;
		data[1] = (char)(newint >> 8);
		i2c0_master_send(AVAGO_SLAVE,data,2);
		color_reg += 2;
	}
	PRINTF1("\n\rIntegration time set to %d!\n\r",newint);
	gain_optimization();
}

void toggle_led(void)
{
	if(led){ IOCLR0 |= (1 << 4); led = 0; }
	else{ IOSET0 |= (1 << 4); led = 1; }
	gain_optimization();
}
void show_color(void)
{
	unsigned char data[2] = {0,0};
	int color_value = 0;
	int current_name = 0;
	int color_reg = 0;

	char *reg_names[4] = {
	"Red",
	"Green",
	"Blue",
	"Clear"
	};
	while(uart0_getch_noblock() != 'A')
	{
		data[0] = CTRL;
		data[1] = 0x01;
		i2c0_master_send(AVAGO_SLAVE,data,2);
		data[0] = 1;
		//while(data[0])
		//{
			data[0] = CTRL;
			data[1] = AVAGO_SLAVE;
			i2c0_master_send_receive(AVAGO_SLAVE,data,2,1);
		//}
		color_value = 0;
		current_name = 0;
		color_reg = DATA_REG_BASE;
		while(current_name <= 3)
		{
			data[0] = color_reg;
			data[1] = AVAGO_SLAVE;
			i2c0_master_send_receive(AVAGO_SLAVE,data,2,1);
			color_value = data[0] << 8;
			data[0] = color_reg + 1;
			i2c0_master_send_receive(AVAGO_SLAVE,data,2,1);
			color_value += data[0];
			PRINTF2("%s = %d\n\r", reg_names[current_name], color_value);
			color_reg += 2;
			current_name += 1;
		}
		PRINTF0("\n\r");
		delay_ms(2000);
	}
}

void sensor_operation(void)
{
	unsigned char data[2] = {0,0};
	
	IOCLR0 |= (1 << 4); // Turn off light source in normal operating evinronment
	// Write 0x02 to control reg to acquire offsets
	data[0] = CTRL;
	data[1] = 0x02;
	//i2c0_master_send(AVAGO_SLAVE,data,2);
	PRINTF0("\n\rOffsets acquired!\n\r");
	// Write 0x01 to config reg to automatically  trim offsets
	data[0] = CONFIG;
	data[1] = 0x01;
	i2c0_master_send(AVAGO_SLAVE,data,2);
	PRINTF0("Offsets set to trim!\n\r");
	IOSET0 |= (1 << 4); // Turn on light source for reading
	// Start reading
	show_color();
}

		
char getch(void)
{
	char c = 0;
	while((c < 48) || (c > 70)){ c = uart0_getch(); }
	PRINTF1("%c",c);
	return c;
}

unsigned int getint(void)
{
	char c = 0;
	int d = 0;
	while((c != 'A'))
	{
			c = getch();
		if(c != 'A')
		{
			d *= 10;
			d += atoi(&c);
		}
	}
	return d;
}

	